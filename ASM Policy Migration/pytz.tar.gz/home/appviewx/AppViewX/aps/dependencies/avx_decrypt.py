##**************************************************************
##
## Copyright (C), AppViewX, Payoda Technologies
##
## Helper script helps to decrpt
##
## V 1.0 / 10 August 2015 / Anand Dileep, Praba, Ahamed / ananddileep.m@payoda.com
##
##
##**************************************************************

# Importing the required modules
import os
import sys

# import appviewx and bson are system depencies - it should be imported after sys path
sys.path.insert(0,'../helper')
path = os.path.dirname(os.path.abspath(__file__))
from bson.objectid import ObjectId
finalpassword = {}


def decrypt(plaintext):
	k = 143
	import base64
	plaintext = base64.b64decode(plaintext)
	cipher = plaintext
	plaintext = ''
	
	for each in cipher:
		p = (ord(each)-k) % 126
	
		if p < 32:
			p+=95
						
		plaintext += chr(p)
		
	return plaintext


def getDevicePassword(devName):
	'''
	Get Device password with parameter as device name
	and return password for the respective
	'''
	import appviewx
	import commands
	connect_db = appviewx.db_connection()
	db = connect_db.appviewx
	collection = db.device
	for value in collection.find({'name':devName}):
		encPassword=value['access'][0]['password']
		key=value['access'][0]['key']
	password=decyrptProcess(encPassword,key)
	return password
	

def decyrptProcess(EncryptedPassword,Key):
	'''
	Helps to decrpt the password using the jar files
	'''	
	import commands	
	decrypt_jar_path = path+'/../../properties/Decrypt.jar'
	java_path = path+'/../../jre/bin/java'
	cmd = java_path + ' -jar ' + decrypt_jar_path + ' ' + EncryptedPassword + ' ' + Key
	#run cli cmd to decrypt jar 
	status, output = commands.getstatusoutput(cmd)
	password = ((output.strip('\n')).split(':')[1]).strip()
	return password

def getConnectorPassword(connectorId):
	'''
	Fetch the CA connector password w.r.t to connectorID
	'''
	import appviewx
	import commands
	connect_db = appviewx.db_connection()
	appviewxDB = connect_db.appviewx
	collectionCertificateConnector = appviewxDB.certConnector
	for value in collectionCertificateConnector.find({"_id":ObjectId(connectorId)}):
		if value['connectorType'] == "CA"  and value['caConnector']['certCAConnectorData']['csrParameters']['challangePassword'] \
			and value['caConnector']['certCAConnectorData']['csrParameters']['confirmPassword'] :
			challangePassword = decyrptProcess(value['caConnector']['certCAConnectorData']['csrParameters']['challangePassword'] , value['caConnector']['certCAConnectorData']['csrParameters']['challangePasswordKey'])
			confirmPassword = decyrptProcess(value['caConnector']['certCAConnectorData']['csrParameters']['confirmPassword'] , value['caConnector']['certCAConnectorData']['csrParameters']['confirmPasswordKey'])
			finalpassword["challangePassword"] = challangePassword
			finalpassword["confirmPassword"] = confirmPassword
			return finalpassword			
		else:
			finalpassword["challangePassword"] = ''
			finalpassword["confirmPassword"] = ''
			return finalpassword			
