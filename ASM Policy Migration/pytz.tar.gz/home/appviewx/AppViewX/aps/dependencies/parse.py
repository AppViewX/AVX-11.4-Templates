#!/usr/bin/python
# Default script to parse the rollback commands syntax
import sys

def parseBKP( par ):
	deviceName,command = par.split(":@")
	print deviceName + ":@backup:" + command
