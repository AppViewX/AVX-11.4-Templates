# Default script to process AVX::UPDATE command and generate output
import sys
import json

def processUpdateCommand(query_dict,key_to_update,value_to_update,action='None'):
	db_update_start = '<db_update>' + '\n'

	if (isinstance(query_dict,dict)):
		query = '<query>' + json.dumps(query_dict) + '</query>' + '\n'
		key = ''
		value = ''
		action_tag = ''

		if(key_to_update!='None' and key_to_update.strip()!=''):
			key = '<key>' + key_to_update + '</key>' + '\n'
		else:
			raise RuntimeError('Invalid AVX::UPDATE param. Invalid key.')

		if(value_to_update!='None' and value_to_update.strip()!=''):
			value = '<value>' + value_to_update + '</value>' + '\n'
		else:
			raise RuntimeError('Invalid AVX::UPDATE param. Invalid value.')

		if(action!='None'):
			if(action.lower() =='add' or action.lower() =='remove'):
				action_tag = '<action>' + action + '</action>' + '\n'
			else:
				raise RuntimeError('Invalid AVX::UPDATE param. Fourth param should either be \'add\' or \'remove\' ')
	else:
		raise RuntimeError('The request json should be a valid dictionary')	

	db_update_end = '</db_update>'
	finalOutput = db_update_start + query + key + value + action_tag + db_update_end
	print finalOutput
