# Default script to process AVX::PUSH command and generate output
import sys
import json
from collections import OrderedDict

def processPushCommand(device_name,source_json, destination_json,protocol = 'scp', fieldId = 'None', port_number = '22', recursive= 'None'):
	push_start_tag = "<push>\n"
	push_end_tag = "</push>"
	data = OrderedDict()
	device_name = '<device>' + device_name + '</device>' + '\n'
	
	if((is_json(source_json)) == False):
		source_json = 'None'
	else:
		source_json = source_json
	data['source_json'] = source_json
	
	if((is_json(destination_json)) == False):
		destination_json = 'None'
	else:
		destination_json = destination_json 
	data['destination_json'] = destination_json
	
	if(protocol!='None'):
		data['protocol'] = protocol
	
	data['fileLocation'] = fieldId
	
	data['port_number'] = port_number
	
	data['recursive'] = recursive
	
	
	final_json = json.dumps(data)
	finalOutput =  push_start_tag + device_name +final_json + '\n' +push_end_tag
	print finalOutput

def is_json(myjson):
	try:
		json_object = json.loads(myjson)
	except ValueError, e:
		return False
	return True