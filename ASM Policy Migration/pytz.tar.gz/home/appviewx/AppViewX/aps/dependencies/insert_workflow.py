#!/usr/bin/python
import socket
from pymongo import MongoClient
mongo_ip = socket.gethostbyname(socket.gethostname())
client = MongoClient(mongo_ip,5000)
client.admin.authenticate('admin','admin')
db = client.workFlowDBEngine

'''
Insert the following workflow in database
'''

false = False
true = True

try:
    result = db.workflow_template.insert_one({
    "_id" : "RI_ServiceNow_Approval_AppViewX_Implement",
    "tasks" : [ 
        {
            "seq_no" : 1,
            "task_id" : "submit",
            "task_name" : "Work Order Initialization",
            "task_type" : "user",
            "roles" : [],
            "end_task" : false
        }, 
        {
            "seq_no" : 2,
            "task_id" : "aps_prevalidation",
            "task_name" : "Pre Validation",
            "task_type" : "service",
            "roles" : [],
            "end_task" : false
        }, 
        {
            "seq_no" : 3,
            "task_id" : "approval2",
            "task_name" : "Approval Level 2",
            "task_flow" : {
                "Manual" : 4,
                "Auto" : 5
            },
            "task_type" : "xor",
            "roles" : [ 
                "admin"
            ],
            "end_task" : false,
            "tags" : {
                "accept_caption" : "Implement",
                "action" : "implement",
                "permission" : {
                    "admin" : "RW",
                    "Surya" : "R",
                    "new_user" : "R",
                    "demo_aps_role" : "R"
                }
            },
            "email_detail" : {
                "pre_template" : "email_awaiting_approval",
                "post_template" : "email_approved"
            }
        }, 
        {
            "seq_no" : 4,
            "task_id" : "aps_implementation",
            "task_name" : "Manual Implementation",
            "task_type" : "service",
            "roles" : [],
            "end_task" : true,
            "email_detail" : {
                "post_template" : "email_implemented"
            }
        }, 
        {
            "seq_no" : 5,
            "task_id" : "ticket_validation",
            "task_name" : "Ticket Validation",
            "task_type" : "timer",
            "roles" : [],
            "end_task" : false
        }, 
        {
            "seq_no" : 6,
            "task_id" : "aps_implementation",
            "task_name" : "Auto Implementation",
            "task_type" : "service",
            "roles" : [],
            "end_task" : true,
            "email_detail" : {
                "post_template" : "email_implemented"
            }
        }, 
        {
            "seq_no" : 7,
            "task_id" : "aps_postvalidation",
            "task_name" : "Post Validation",
            "task_type" : "service",
            "roles" : [],
            "end_task" : true
        }
    ]
})

    print "Successfully inserted the workflow in Data Base"
except Exception , e:
    print e
