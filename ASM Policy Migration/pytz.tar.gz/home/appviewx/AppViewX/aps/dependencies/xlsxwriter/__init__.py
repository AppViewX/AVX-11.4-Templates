__version__ = '0.9.6'
__VERSION__ = __version__
from .workbook import Workbook
